#!/bin/sh
set -eu
set -a
. /appdata/docker/supabase/.env.local
set +a
rm -f /docker-entrypoint-initdb.d/*
cp /appdata/docker/supabase/init/* /docker-entrypoint-initdb.d/
exec docker-entrypoint.sh "$@"
