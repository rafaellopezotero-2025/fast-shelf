#!/bin/sh
set -eu
set -a
. /appdata/docker/supabase/.env.local
set +a
export PGRST_DB_URI="postgres://authenticator:${POSTGRES_PASSWORD}@db:5432/postgres"
export PGRST_DB_SCHEMAS=public
export PGRST_DB_ANON_ROLE=anon
export PGRST_JWT_SECRET="$JWT_SECRET"
export PGRST_DB_USE_LEGACY_GUCS=false
exec postgrest
