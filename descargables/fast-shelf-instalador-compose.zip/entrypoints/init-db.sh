#!/bin/bash
set -euo pipefail
APP=/appdata
set -a
. "$APP/docker/supabase/.env.local"
set +a
export PGPASSWORD="$POSTGRES_PASSWORD"
psql_run() { psql -h db -U postgres -d postgres -v ON_ERROR_STOP=1 "$@"; }

echo "Esperando las tablas de autenticación..."
for i in $(seq 1 90); do
  if psql_run -tAc "SELECT to_regclass('auth.users') IS NOT NULL" 2>/dev/null | grep -q t; then break; fi
  sleep 2
done
psql_run -tAc "SELECT to_regclass('auth.users') IS NOT NULL" | grep -q t || { echo "GoTrue no creó auth.users." >&2; exit 1; }

psql_run <<'SQL' >/dev/null
CREATE TABLE IF NOT EXISTS public._migraciones_aplicadas (archivo text PRIMARY KEY, aplicada_at timestamptz NOT NULL DEFAULT now());
GRANT ALL ON public._migraciones_aplicadas TO service_role;
ALTER TABLE public._migraciones_aplicadas ENABLE ROW LEVEL SECURITY;
SQL

for f in "$APP"/supabase/migrations/*.sql; do
  name="$(basename "$f")"
  if psql_run -tAc "SELECT 1 FROM public._migraciones_aplicadas WHERE archivo='$name';" | grep -q 1; then continue; fi
  echo "Aplicando migración $name"
  { printf 'BEGIN;\n'; cat "$f"; printf "\nINSERT INTO public._migraciones_aplicadas (archivo) VALUES ('%s');\nCOMMIT;\n" "$name"; } | psql_run >/dev/null
done

if ! psql_run -tAc 'SELECT count(*) FROM auth.users' | grep -qx '0'; then
  echo "Ya hay cuentas locales; se omite la importación para evitar duplicarlas."
else
  BACKUP_FILE="$(cat "$APP/restore/backup-path")"
  echo "Importando cuentas, perfiles y roles desde el backup..."
  for spec in 'auth users' 'auth identities' 'public profiles' 'public user_roles'; do
    read -r schema table <<<"$spec"
    pg_restore --data-only --no-owner --no-privileges -f - -n "$schema" -t "$table" "$BACKUP_FILE" \
      | sed -e '/^\\restrict /d' -e '/^\\unrestrict /d' -e '/^SET transaction_timeout = 0;/d' \
      | psql_run >/dev/null
  done
  psql_run -tAc "SELECT count(*) FROM auth.users" | grep -Eq '^[1-9][0-9]*$' || { echo "El backup no aportó cuentas." >&2; exit 1; }
  psql_run -tAc "SELECT count(*) FROM public.user_roles WHERE role::text='admin'" | grep -Eq '^[1-9][0-9]*$' || { echo "El backup no contiene un administrador." >&2; exit 1; }
fi

psql_run -c "NOTIFY pgrst, 'reload schema';" >/dev/null
echo "Base de datos lista."
