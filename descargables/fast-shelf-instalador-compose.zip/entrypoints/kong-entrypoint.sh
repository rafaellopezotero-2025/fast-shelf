#!/bin/sh
set -eu
set -a
. /appdata/docker/supabase/.env.local
set +a
umask 077
sed -e "s|\${ANON_KEY}|${ANON_KEY}|g" \
    -e "s|\${SERVICE_ROLE_KEY}|${SERVICE_ROLE_KEY}|g" \
    /appdata/docker/supabase/kong.yml > /tmp/kong.yml
export KONG_DATABASE=off
export KONG_DECLARATIVE_CONFIG=/tmp/kong.yml
export KONG_DNS_ORDER=LAST,A,CNAME
export KONG_PLUGINS=request-transformer,cors,key-auth,acl
exec /docker-entrypoint.sh kong docker-start
