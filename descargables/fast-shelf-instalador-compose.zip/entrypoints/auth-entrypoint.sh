#!/bin/sh
set -eu
set -a
. /appdata/docker/supabase/.env.local
set +a
export GOTRUE_API_HOST=0.0.0.0
export GOTRUE_API_PORT=9999
export API_EXTERNAL_URL="$PUBLIC_URL"
export GOTRUE_DB_DRIVER=postgres
export GOTRUE_DB_DATABASE_URL="postgres://supabase_auth_admin:${POSTGRES_PASSWORD}@db:5432/postgres?search_path=auth&sslmode=disable"
export GOTRUE_SITE_URL="$SITE_URL"
export GOTRUE_URI_ALLOW_LIST="$SITE_URL"
export GOTRUE_DISABLE_SIGNUP=false
export GOTRUE_JWT_SECRET="$JWT_SECRET"
export GOTRUE_JWT_EXP=3600
export GOTRUE_JWT_AUD=authenticated
export GOTRUE_JWT_DEFAULT_GROUP_NAME=authenticated
export GOTRUE_EXTERNAL_EMAIL_ENABLED=true
export GOTRUE_MAILER_AUTOCONFIRM=true
export GOTRUE_LOG_LEVEL=info
auth migrate
exec auth serve
