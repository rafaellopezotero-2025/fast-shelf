#!/bin/bash
set -euo pipefail
APP_DIR=/appdata
if [ -f "$APP_DIR/.fast-shelf-prepared" ]; then echo "La aplicación ya fue preparada; se conservan sus datos."; exit 0; fi
for f in /input/app.zip /input/backup.zip; do [ -r "$f" ] || { echo "Falta $f" >&2; exit 1; }; done
rm -rf "$APP_DIR"/* "$APP_DIR"/.[!.]* "$APP_DIR"/..?* 2>/dev/null || true
mkdir -p /tmp/fast-shelf-source "$APP_DIR/restore"
unzip -q /input/app.zip -d /tmp/fast-shelf-source
PROJECT_ROOT="$(find /tmp/fast-shelf-source -maxdepth 4 -type f -name package.json -printf '%h\n' | head -n 1)"
[ -n "$PROJECT_ROOT" ] || { echo "No encuentro package.json dentro de fast-shelf.zip." >&2; exit 1; }
cp -a "$PROJECT_ROOT"/. "$APP_DIR"/
if unzip -tq /input/backup.zip >/dev/null 2>&1; then unzip -oq /input/backup.zip -d "$APP_DIR/restore"; else cp /input/backup.zip "$APP_DIR/restore/fast-shelf.backup"; fi
BACKUP_FILE="$(find "$APP_DIR/restore" -type f \( -name '*.backup' -o -name '*.dump' -o -name '*.tar' \) | head -n 1)"
[ -n "$BACKUP_FILE" ] || { echo "No encontré el respaldo PostgreSQL dentro del ZIP." >&2; exit 1; }
printf '%s\n' "$BACKUP_FILE" > "$APP_DIR/restore/backup-path"
SERVER_IP="$(ip -o -4 route get 1.1.1.1 2>/dev/null | awk '{for(i=1;i<=NF;i++) if($i=="src"){print $(i+1); exit}}')"
if [ -z "$SERVER_IP" ]; then SERVER_IP="$(ip -o -4 addr show scope global | awk 'NR==1 {split($4,a,"/"); print a[1]}')"; fi
[ -n "$SERVER_IP" ] || { echo "No pude detectar la IP local del servidor." >&2; exit 1; }
cd "$APP_DIR"
bash scripts/generar-claves.sh
node --input-type=module - "$APP_DIR/docker/supabase/.env.local" "$SERVER_IP" <<'NODE'
import fs from 'node:fs';
const [file, ip] = process.argv.slice(2);
let data = fs.readFileSync(file, 'utf8');
for (const [key, value] of Object.entries({ PUBLIC_URL: `http://${ip}:8000`, SITE_URL: `http://${ip}:3000` })) {
  const line = new RegExp(`^${key}=.*$`, 'm');
  data = line.test(data) ? data.replace(line, `${key}=${value}`) : `${data.trimEnd()}\n${key}=${value}\n`;
}
fs.writeFileSync(file, data, { mode: 0o600 });
NODE
echo "Instalando dependencias..."
npm install --include=dev --no-audit --no-fund
echo "Compilando para uso local..."
npm run build:local
chmod 600 docker/supabase/.env.local .env.offline.local docker/supabase/kong.generated.local.yml
touch "$APP_DIR/.fast-shelf-prepared"
echo "Aplicación preparada en http://${SERVER_IP}:3000"
